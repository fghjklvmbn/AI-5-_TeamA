import gradio as gr
from .events import get_idle_state
from frontend.pages.home.events import (
    open_recorder,
    save_record,
    voice_state
)

def home_page():

    with gr.Column(
        elem_classes=["page-container"]
    ):

        mic_btn = gr.Button(
            "🎤",
            elem_id="mic-button"
        )

        audio_input = gr.Audio(
            sources=["microphone"],
            type="filepath",
            visible=False,
            label="음성 녹음"
        )

        # 파이프라인 연결점. 채팅으로 바꿈
        save_btn = gr.Button(
            "채팅",
            visible=False
        )
        save_btn.click(

            fn=show_processing,

            outputs=[
                home_view,
                chat_view,
                voice_view,
                settings_view,
                processing_view
            ]

        ).then(

            fn=run_voice_chat,

            inputs=[
                audio_input,
                session_state
            ],

            outputs=[
                chatbot,
                response_audio
            ]
        ).then(

            fn=run_voice_chat,

            inputs=[
                audio_input,
                session_state
            ],

            outputs=[
                chatbot,
                response_audio
            ]
        )

        voice_selector = gr.Dropdown(
            choices=[
                "기본 음성"
            ],
            value="기본 음성"
        )

        # status_box = gr.Textbox(
        #     value=get_idle_state(),
        #     interactive=False,
        #     elem_classes=["status-box"]
        # )

        return (
            mic_btn,
            audio_input,
            save_btn,
            voice_state
            # status_box
        )
